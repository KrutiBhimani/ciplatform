<?php include "header.php"; ?>
<?php 
$first_name= "";
$last_name="";
include "navbar1.php"; ?>
<br/><br/>
<div class="container-lg">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                <div style="height:100%;">
                    <img class="ps-1 pe-1" src="../Assets/image2.png" width="100%">
                    <div class="row pe-3 ps-3 pt-1">
                        <img src="../Assets/CSR-initiative-stands-for-Coffee--and-Farmer-Equity-5.png" class="pe-0 ps-0"
                            style="width:calc(100%/4);">
                        <img src="../Assets/img2.png" class="ps-1 pe-0" style="width:calc(100%/4);">
                        <img src="../Assets/Grow-Trees-On-the-path-to-environment-sustainability-4.png" class="ps-1 pe-0"
                            style="width:calc(100%/4);">
                        <img src="../Assets/img22.png" class="ps-1 pe-0" style="width:calc(100%/4);">

                    </div>
                </div>

            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-12 mt-5">
                <div class="d-flex justify-content-between">
                    <div>
                        <img src="../Assets/volunteer2.png" class="rounded-circle" height="82px" width="78">
                        <p class="mb-0" style="font-size:13px ;">Charles Vigue</p>
                    </div>
                    <div class="d-flex align-items-end">
                        <div class="bdg2"><img src="../Assets/eye.png" class="me-2">12000 view</div>
                    </div>
                </div>
                <p class="mt-4" style="font-size:calc(11px + 0.2vw);">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                    et dolore magna aliqua.
                </p>
                <p style="font-size:calc(11px + 0.2vw);">
                    Ut enim ad minim veniam. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                    doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore.
                </p>
                <p style="font-size:calc(11px + 0.2vw);">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
                    et dolore magna aliqua. Ut enim ad minim veniam. Sed ut perspiciatis unde omnis iste natus error sit
                    voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore.
                </p>
                <div class="row mt-3 mb-3">
                    <div class="col-lg-7 col-md-12 col-sm-12 col-12 mt-2">
                        <div class="col-example2 text-center" style="font-size:calc(13px + 0.2vw);">
                            <img src="../Assets/add1.png" alt="" class="mb-1" style="height:15px ;">
                            Recommend to a Co-Worker
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-12 col-sm-12 col-12 mt-2">
                        <div class="col-example text-center" style="font-size:calc(13px + 0.2vw);">
                            Open Mission
                            <img src="../Assets/right-arrow.png" alt="" class="ms-3 mb-1" style="height:15px ;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        <a class="nav-link active1 gray ps-0" data-toggle="tab" href="#mission">Grow Tress - On the path
                            to environment sustainbility</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane show active" id="mission">
                        <p style="font-size:calc(10px + 0.1vw);" class="mt-4 mb-3">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                            laboris nisi ut aliquip ex ea commodo consequat.
                        </p>
                        <p style="font-size:calc(10px + 0.1vw);" class="mb-3">
                            Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                            pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
                            mollit anim id est laborum.
                        </p>
                        <p style="font-size:calc(10px + 0.1vw);" class="mb-3">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                            laboris nisi ut aliquip ex ea commodo consequat.Duis aute irure dolor in reprehenderit in
                            voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                            cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                        </p>
                        <p style="font-size:calc(10px + 0.1vw);" class="mb-2">
                            We use these technologies for a number of purposes, such as:
                        </p>
                        <div class="col-lg-7 col-md-8 col-sm-10 col-12 ms-0 ps-0">
                            <ul style="font-size:calc(10px + 0.1vw);" class="mb-3">
                                <li>
                                    <p style="font-size:calc(10px + 0.1vw);" class="mb-2">
                                        But I must explain to you how all this mistaken idea of denouncing pleasure and
                                        praising pain.
                                    </p>
                                </li>
                                <li>
                                    <p style="font-size:calc(10px + 0.1vw);" class="mb-2">
                                        At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis
                                        praesentium voluptatum deleniti atque excepturi sint occaecati cupiditate non
                                        provident, similique sunt in culpa qui officia deserunt mollitia animi.
                                    </p>
                                </li>
                                <li>
                                    <p style="font-size:calc(10px + 0.1vw);" class="mb-2">
                                        On the other hand, we denounce with righteous indignation and dislike men who
                                        are so
                                        beguiled and demoralized
                                    </p>
                                </li>
                                <li>
                                    <p style="font-size:calc(10px + 0.1vw);" class="mb-2">
                                        But I must explain to you how all this mistaken idea of denouncing pleasure and
                                        praising pain.
                                    </p>
                                </li>
                                <li>
                                    <p style="font-size:calc(10px + 0.1vw);" class="mb-2">
                                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                        incididunt ut labore et dolore
                                    </p>
                                </li>
                            </ul>
                        </div>
                        <p style="font-size:calc(10px + 0.1vw);" class="mb-5">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                            laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
                            voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                            cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include "footer.php"; ?>
</body>

</html>