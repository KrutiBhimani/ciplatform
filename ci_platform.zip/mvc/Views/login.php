<div class="container-fluid">
  <div class="row height100per">
    <div class="col-lg-8 col-md-8 col-sm-12 col-12 p-0">
      <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators" style="bottom:2%">
          <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1" style="border-top: 0; border-bottom:0;border-radius:15px;width:8px;height: 8px;"></li>
          <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2" style="border-top: 0; border-bottom:0;border-radius:15px;width:8px;height: 8px;"></li>
          <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3" style="border-top: 0; border-bottom:0;border-radius:15px;width:8px;height: 8px;"></li>
          <li data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3" aria-label="Slide 4" style="border-top: 0; border-bottom:0;border-radius:15px;width:8px;height: 8px;"></li>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="../Assets/Grow-Trees-On-the-path-to-environment-sustainability-login.png" class="d-block w-100" alt="..." style="height:100% ;">
            <div class="carousel-caption" style="text-align:start; bottom:10%">
              <p class="Sed-ut-perspiciatis-unde-omnis-iste-natus-voluptatem mb-3">Sed ut perspiciatis unde omnis<br />iste natus voluptatem.</p>
              <p class="Lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit-sed-do m-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="../Assets/Grow-Trees-On-the-path-to-environment-sustainability-login.png" class="d-block w-100" alt="..." style="height:100% ;">
            <div class="carousel-caption" style="text-align:start; bottom:10%">
              <p class="Sed-ut-perspiciatis-unde-omnis-iste-natus-voluptatem mb-3">Sed ut perspiciatis unde omnis<br />iste natus voluptatem.</p>
              <p class="Lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit-sed-do m-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="../Assets/Grow-Trees-On-the-path-to-environment-sustainability-login.png" class="d-block w-100" alt="..." style="height:100% ;">
            <div class="carousel-caption" style="text-align:start; bottom:10%">
              <p class="Sed-ut-perspiciatis-unde-omnis-iste-natus-voluptatem mb-3">Sed ut perspiciatis unde omnis<br />iste natus voluptatem.</p>
              <p class="Lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit-sed-do m-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            </div>
          </div>
          <div class="carousel-item">
            <img src="../Assets/Grow-Trees-On-the-path-to-environment-sustainability-login.png" class="d-block w-100" alt="..." style="height:100% ;">
            <div class="carousel-caption" style="text-align:start; bottom:10%">
              <p class="Sed-ut-perspiciatis-unde-omnis-iste-natus-voluptatem mb-3">Sed ut perspiciatis unde omnis<br />iste natus voluptatem.</p>
              <p class="Lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit-sed-do m-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-4 col-sm-12 d-md-flex align-items-center position-relative">
      <div class="Layer-52">
        <br />
        <form method="post"  enctype="multipart/form-data">
          <div class="form-group">
            <span class="Email">Email Address</span>
            <input type="email" placeholder="Enter your email address..." name="email" class="Rounded-Rectangle-2 form-control" style="font-size:14px; height:40px;" required>
          </div>
          <div class="form-group">
            <span class="Email">Password</span>
            <input type="password" placeholder="Enter your password..." name="password" class="Rounded-Rectangle-2 form-control" style="font-size:14px; height:40px;" required>
          </div>
          <button class="login" name="login" type="submit">Login</button>
        </form>
        <p class="text-center mb-3">
          <a href="forgot" class="lost">Lost your password?</a>
        </p>
        <p class="text-center lost mb-0">
          Don't have an account?
          <a href="register" style="color:blue;">Create an account</a>
        </p>
      </div>
      <a href="policy.html" class="text-center position-absolute bottom-0 start-50 translate-middle p-0 m-0 mt-3 Privacy-Policy">Privacy Policy</a>
    </div>
  </div>
</div>
</body>

</html>