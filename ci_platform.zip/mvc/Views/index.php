<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Index</title>
</head>
<body>
    <h1>INDEX</h1>
</body>
</html>