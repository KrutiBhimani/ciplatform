<?php

date_default_timezone_set('Asia/Kolkata');
require_once('Model/Model.php');
session_start();

class Controller extends Model
{

	function __construct()
	{
		parent::__construct();

		if (isset($_SERVER['PATH_INFO'])) {
			switch ($_SERVER['PATH_INFO']) {
				case '/index':
					include 'Views/index.php';
					break;
				case '/register':
					if (isset($_POST['register'])) {
						$password = $_POST['password'];
						$password2 = $_POST['password2'];
						if ($password == $password2) {
							$insert_data = [
								'first_name' => $_POST['first_name'],
								'last_name' => $_POST['last_name'],
								'email' => $_POST['email'],
								'password' => $_POST['password'],
								'phone_number' => $_POST['phone_number'],
								'city_id' => 1,
								'country_id' => 1
							];
							$insertEx = $this->InsertData('user', $insert_data);
							if ($insertEx['Code']) {

?>
								<script type="text/javascript">
									alert("<?php echo $insertEx['Message'] ?>");
									window.location.href = 'login';
								</script>
							<?php
							} else {
							?>
								<script type="text/javascript">
									alert("<?php echo $insertEx['Message'] ?>");
									window.location.href = 'register';
								</script>
					<?php
							}
						}
					}
					include 'Views/header.php';
					include 'Views/registration.php';
					break;
				case '/login':
					//if (isset($_SESSION['user_data'])) {

					?>
					<!-- <script type="text/javascript">
							window.location.href = 'home';
						</script> -->
					<?php
					//} else if (isset($_SESSION['admin_data'])) {
					?>
					<!-- <script type="text/javascript">
							window.location.href = 'admin';
						</script> -->
					<?php
					//}
					if (isset($_POST['login'])) {
						$email = mysqli_real_escape_string($this->connection, $_POST['email']);
						$password = mysqli_real_escape_string($this->connection, $_POST['password']);

						$loginEx = $this->LoginData($email, $password);
						if ($loginEx['Code']) {
							$_SESSION['user_data'] = $loginEx['Data1'];
							$_SESSION['admin_data'] = $loginEx['Data2'];
							if ($_SESSION['user_data']) {
					?>
								<script type="text/javascript">
									alert("<?php echo $loginEx['Message'] ?>");
									window.location.href = 'home';
								</script>
							<?php
							} else if ($_SESSION['admin_data']) {
							?>
								<script type="text/javascript">
									alert("<?php echo $loginEx['Message'] ?>");
									window.location.href = 'admin?page=1';
								</script>
							<?php
							}
						} else {
							?>
							<script type="text/javascript">
								alert("<?php echo $loginEx['Message'] ?>");
								window.location.href = 'login';
							</script>
						<?php
						}
					}
					include 'Views/header.php';
					include 'Views/login.php';
					break;

				case '/home':
					if (!isset($_SESSION['user_data'])) {
						?>
						<script type="text/javascript">
							window.location.href = 'login';
						</script>
					<?php
					}
					include 'Views/header.php';
					include 'Views/navbar1.php';
					include 'Views/navbar2.php';
					include 'Views/home.php';
					break;

				case '/logout':
					if (isset($_SESSION['admin_data'])) {
						unset($_SESSION['admin_data']);
						session_destroy();
					} else if (isset($_SESSION['user_data'])) {
						unset($_SESSION['user_data']);
						session_destroy();
					}
					?>
					<script type="text/javascript">
						alert("logged out successfully.");
						window.location.href = 'login';
					</script>
					<?php
					break;
				case '/forgot':
					if (isset($_POST['forgot'])) {
						$email = mysqli_real_escape_string($this->connection, $_POST['email']);
						$resetEx = $this->ResetPass($email);
					?>
						<script type="text/javascript">
							alert("<?php echo $resetEx['Message'] ?>");
						</script>
						<?php
						if ($resetEx['Code']) {
							$_SESSION['reset_data'] = $resetEx['Data'];
							$token = md5(2418 * 2) . substr(md5(uniqid(rand(), 1)), 3, 10);
							if ($_SESSION['reset_data']) {
								$link = "<a href='http://localhost/ci-platform/mvc/reset?key=" . $_SESSION['reset_data']->email . "&t=" . $token . "'>Click To Reset password</a>";
								require 'Views/PHPMailerAutoload.php';
								require_once('../PHPMailer/src/PHPMailer.php');
								require_once('../PHPMailer/src/Exception.php');
								require_once('../PHPMailer/src/OAuthTokenProvider.php');
								require_once('../PHPMailer/src/OAuth.php');
								require_once('../PHPMailer/src/POP3.php');
								require_once('../PHPMailer/src/SMTP.php');
								if (empty($errors)) {
									$insert_data = [
										'email' => $_SESSION['reset_data']->email,
										'created_at' => date("Y/m/d H:i:s"),
										'token' => $token
									];
									$insertEx = $this->InsertData('password_reset', $insert_data);
									$mail = new PHPMailer\PHPMailer\PHPMailer(true); //defaults to using php "mail()"; the true param means it will throw exceptions on errors, which we need to catch
									try {
										//$mail->SMTPDebug = 1;                               // Enable verbose debug output
										$mail->isSMTP();                                    // Set mailer to use SMTP
										$mail->Host = 'smtp.office365.com'; // Specify main and backup SMTP servers
										$mail->SMTPAuth = true;                             // Enable SMTP authentication
										$mail->Username = 'krutipatel5773@outlook.com';           // SMTP username
										$mail->Password = 'kruti9607';                       // SMTP password
										$mail->SMTPSecure = 'tls';                          // Enable TLS encryption, `ssl` also accepted
										$mail->Port = 587;                                  // TCP port to connect, tls=587, ssl=465
										$mail->From = 'krutipatel5773@outlook.com';
										$mail->FromName = 'kruti bhimani';
										$mail->addAddress($email);     // Add a recipient
										$mail->addReplyTo($email);
										$mail->WordWrap = 50;                                 // Set word wrap to 50 characters
										$mail->isHTML(false);                                  // Set email format to HTML
										$mail->Subject = 'Reset Password';
										$mail->Body    = 'Click On This Link to Reset Password ' . $link . '';
										$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
										if (!$mail->send()) {
											echo 'Message could not be sent.';
											echo 'Mailer Error: ' . $mail->ErrorInfo;
										} else { ?>
											<script type="text/javascript">
												alert("message sent.");
												window.location.href = 'forgot';
											</script>
								<?php }
										$errors[] = "Send mail sucsessfully";
									}
									// catch (phpmailerException $e) 
									// {
									//   $errors[] = $e->errorMessage(); //Pretty error messages from PHPMailer
									// } 
									catch (Exception $e) {
										$errors[] = $e->getMessage(); //Boring error messages from anything else!
									}
								}
							} else { ?>
								<script type="text/javascript">
									alert("user not found");
									window.location.href = 'forgot';
								</script>
								<?php }
						}
					}
					include 'Views/header.php';
					include 'Views/forgotpsd.php';
					break;
				case '/reset':
					if ($_GET['key'] && $_GET['t']) {
						$email = $_GET['key'];
						$token = $_GET['t'];
						$hourEx = $this->CheckHour($token);
						if ($hourEx['Code']) {
							$created_at = $hourEx['Data']->created_at;
							$start_date = new DateTime($created_at);
							$end_date = new DateTime(date("Y-m-d H:i:s"));
							$interval = $start_date->diff($end_date);
							$min = $interval->format('%i');
							$hour = $interval->format('%h');
							$mon = $interval->format('%m');
							$day = $interval->format('%d');
							$year = $interval->format('%y');
							$diff = $year + $mon + $day * 24 * 60 + $hour * 60 + $min;
							if ($diff <= 240) {
								if (isset($_SESSION['reset_data'])) {
									$email = $_SESSION['reset_data']->email;
									if (isset($_POST['reset'])) {
										$password = mysqli_real_escape_string($this->connection, $_POST['password']);
										$password2 = mysqli_real_escape_string($this->connection, $_POST['password2']);
										if ($password == $password2) {
											$changeEx = $this->UpdatePass($email, $password);
											if ($changeEx['Code']) {
								?>
												<script type="text/javascript">
													alert("<?php echo $changeEx['Message'] ?>");
													window.location.href = 'login';
												</script>
											<?php
											} else {
											?>
												<script type="text/javascript">
													alert("<?php echo $changeEx['Message'] ?>");
													window.location.href = 'register';
												</script>
								<?php
											}
										}
									}
									include 'Views/header.php';
									include 'Views/resetpsd.php';
									break;
								}
							} else { ?>
								<script type="text/javascript">
									alert("link expired");
									window.location.href = 'forgot';
								</script>
						<?php }
						}
					} else { ?>
						<script type="text/javascript">
							window.location.href = 'forgot';
						</script>
					<?php }

				case '/admin':
					if (!isset($_SESSION['admin_data'])) {
					?>
						<script type="text/javascript">
							window.location.href = 'login';
						</script>
					<?php
					}
					if (isset($_SESSION['admin_data'])) {
						$firstname = $_SESSION['admin_data']->first_name;
						$lastname = $_SESSION['admin_data']->last_name;
						$avtar = $_SESSION['admin_data']->avatar;
						$pagecount = 5;
						if (isset($_GET['page'])) {
							$page = $_GET['page'];
						} else
							$page = "";
						if ($page == "" || $page == 1){
							$postno = 0;}
						else
							$postno = ($page * $pagecount) - $pagecount;
						$selectData1 = $this->SelectUser();
						$cnt = $selectData1['Data'];
						$cnt = ceil($cnt / $pagecount);
						$selectData1 = $this->SelectData('user', $postno, $pagecount);
						$users = $selectData1['Data'];
						if (isset($_POST['searchuser'])) {
							$where = [
								'first_name' => $_POST['searchuser'],
								'last_name' => $_POST['searchuser'],
								'email' => $_POST['searchuser'],
								'employee_id' => $_POST['searchuser'],
								'department' => $_POST['searchuser']
							];
							$selectData1 = $this->SelectData('user',0, 5, $where);
							$users = $selectData1['Data'];
						}
						$selectData2 = $this->SelectData('cms_page');
						$pages = $selectData2['Data'];
						$selectData3 = $this->SelectData('mission');
						$missions = $selectData3['Data'];
						$selectData4 = $this->SelectData('mission_theme');
						$themes = $selectData4['Data'];
						$selectData5 = $this->SelectData('skill');
						$skills = $selectData5['Data'];
						$selectData6 = $this->SelectJoinApp();
						$apps = $selectData6['Data'];
						$selectData7 = $this->SelectJoinStory();
						$storys = $selectData7['Data'];
						$selectData8 = $this->SelectData('banner');
						$banners = $selectData8['Data'];
						$i = 0;
					}
					include 'Views/header.php';
					include 'Views/adminsidebar.php';
					include 'Views/admin.php';
					break;

				case '/adduser':
					if (!isset($_SESSION['admin_data'])) {
						?>
						<script type="text/javascript">
							window.location.href = 'login';
						</script>
						<?php
					}
					if (isset($_SESSION['admin_data'])) {
						$firstname = $_SESSION['admin_data']->first_name;
						$lastname = $_SESSION['admin_data']->last_name;
						$avtar = $_SESSION['admin_data']->avatar;
						$selectData1 = $this->SelectData('user');
						$users = $selectData1['Data'];
						$selectData2 = $this->SelectData('cms_page');
						$pages = $selectData2['Data'];
						$selectData3 = $this->SelectData('mission');
						$missions = $selectData3['Data'];
						$selectData4 = $this->SelectData('mission_theme');
						$themes = $selectData4['Data'];
						$selectData5 = $this->SelectData('skill');
						$skills = $selectData5['Data'];
						$selectData6 = $this->SelectJoinApp();
						$apps = $selectData6['Data'];
						$selectData7 = $this->SelectJoinStory();
						$storys = $selectData7['Data'];
						$selectData8 = $this->SelectData('banner');
						$banners = $selectData8['Data'];
						$selectData9 = $this->SelectData('city');
						$cities = $selectData9['Data'];
						$selectData10 = $this->SelectData('country');
						$countries = $selectData10['Data'];
						$i = 1;
						if (isset($_POST['add_user'])) {
							$avatar = $_FILES['avatar']['name'];
							$avatar_temp = $_FILES['avatar']['tmp_name'];
							$insert_data = [
								'first_name' => $_POST['first_name'],
								'last_name' => $_POST['last_name'],
								'email' => $_POST['email'],
								'password' => $_POST['password'],
								'phone_number' => $_POST['phone_number'],
								'city_id' => $_POST['city_id'],
								'country_id' => $_POST['country_id'],
								'employee_id' => $_POST['employee_id'],
								'department' => $_POST['department'],
								'profile_text' => $_POST['profile_text'],
								'status' => $_POST['status'],
								'avatar' => $avatar
							];
							$insertEx = $this->InsertData('user', $insert_data);
							if ($insertEx['Code']) {
								if (!is_null($avatar)) {
									move_uploaded_file($avatar_temp, '../Assets/' . $avatar);
								}
						?>
								<script type="text/javascript">
									alert("<?php echo $insertEx['Message'] ?>");
									window.location.href = 'admin';
								</script>
							<?php
							} else {
							?>
								<script type="text/javascript">
									alert("<?php echo $insertEx['Message'] ?>");
									window.location.href = 'adduser';
								</script>
						<?php
							}
						}
					}
					include 'Views/header.php';
					include 'Views/adminsidebar.php';
					include 'Views/admin.php';
					break;

				case '/edituser':
					if (!isset($_SESSION['admin_data'])) {
						?>
						<script type="text/javascript">
							window.location.href = 'login';
						</script>
						<?php
					}
					if (isset($_SESSION['admin_data'])) {
						$firstname = $_SESSION['admin_data']->first_name;
						$lastname = $_SESSION['admin_data']->last_name;
						$avtar = $_SESSION['admin_data']->avatar;
						$selectData1 = $this->SelectData('user');
						$users = $selectData1['Data'];
						$selectData2 = $this->SelectData('cms_page');
						$pages = $selectData2['Data'];
						$selectData3 = $this->SelectData('mission');
						$missions = $selectData3['Data'];
						$selectData4 = $this->SelectData('mission_theme');
						$themes = $selectData4['Data'];
						$selectData5 = $this->SelectData('skill');
						$skills = $selectData5['Data'];
						$selectData6 = $this->SelectJoinApp();
						$apps = $selectData6['Data'];
						$selectData7 = $this->SelectJoinStory();
						$storys = $selectData7['Data'];
						$selectData11 = $this->SelectData('city');
						$cities = $selectData11['Data'];
						$selectData10 = $this->SelectData('country');
						$countries = $selectData10['Data'];
						$selectData8 = $this->SelectData('banner');
						$banners = $selectData8['Data'];
						$encrypted_id = $_GET['edit'];
						$salt="SECRET_STUFF";
						$decrypted_id_raw = base64_decode($encrypted_id);
                        $decrypted_id = preg_replace(sprintf('/%s/', $salt), '', $decrypted_id_raw);
						$user_id = $decrypted_id;
						$selectData9 = $this->SelectById($user_id);
						$user = $selectData9['Data'];
						$i = 2;
						if (isset($_POST['edit_user'])) {
							$avatar = $_FILES['avatar']['name'];
							$avatar_temp = $_FILES['avatar']['tmp_name'];
							if (empty($avatar)) {
								$selectData12 = $this->SelectId($user_id);
								$avatar = $selectData12['Data']->avatar;
							}
							$update_data = [
								'user_id' => $user_id,
								'first_name' => $_POST['first_name'],
								'last_name' => $_POST['last_name'],
								'email' => $_POST['email'],
								'password' => $_POST['password'],
								'phone_number' => $_POST['phone_number'],
								'city_id' => $_POST['city_id'],
								'country_id' => $_POST['country_id'],
								'employee_id' => $_POST['employee_id'],
								'department' => $_POST['department'],
								'profile_text' => $_POST['profile_text'],
								'status' => $_POST['status'],
								'avatar' => $avatar
							];
							$upd_data = $this->UpdateData('user', $update_data, $user_id);
							if ($upd_data) {
						?>
								<script type="text/javascript">
									alert("Data update successfully.");
									window.location.href = 'admin';
								</script>
							<?php
							} else {
							?>
								<script type="text/javascript">
									alert("Something Went Wrong.");
									window.location.href = 'edituser';
								</script>
						<?php
							}
						}
					}
					include 'Views/header.php';
					include 'Views/adminsidebar.php';
					include 'Views/admin.php';
					break;
				case '/deleteuser':
					$delete_user_id = $_GET['delete'];
					$delete_data = $this->DeleteData('user', $delete_user_id);
					if ($delete_data) {
						?>
						<script type="text/javascript">
							alert("Data deleted successfully.");
							window.location.href = 'admin';
						</script>
					<?php
					} else {
					?>
						<script type="text/javascript">
							alert("Something Went Wrong.");
							window.location.href = 'admin';
						</script>
<?php
					}
				default:

					break;
			}
		}
	}
}

$obj = new Controller;


?>