<?php

require 'mvc/index.php';

?>